import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { FacturaComponent } from './components/factura/factura.component';
import { HistorialMedComponent } from './components/historial-med/historiaClinica.component';
import { ClinicoComponent } from './components/clinico/clinico.component';
import { DiagnosticoComponent } from './components/diagnostico/diagnostico.component';
import { ContactoComponent } from './components/contacto/contacto.component';
import { DescuentoComponent } from './components/descuento/descuento.component';
import { SomosComponent } from './components/somos/somos.component';
import { DoctoresComponent } from './components/doctores/doctores.component';
import { HorariosComponent } from './components/horarios/horarios.component';
import { ConsultasComponent } from './components/consultas/consultas.component';
import { AgendarCitaComponent } from './components/agendar-cita/agendar-cita.component';
import { PrintFacturaComponent } from './components/print-factura/print-factura.component';

export const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'descuento', component: DescuentoComponent },
    { path: 'agregarFactura', component: FacturaComponent },
    { path: 'historial', component: HistorialMedComponent },
    { path: 'clinico', component: ClinicoComponent },
    { path: 'doctor', component: DoctoresComponent },
    { path: 'horario', component: HorariosComponent },
    { path: 'consultas', component: ConsultasComponent },
    { path: 'agendar', component: AgendarCitaComponent },
    { path: 'print', component: PrintFacturaComponent },


    { path: 'diagnostico', component: DiagnosticoComponent },
    { path: 'contacto', component: ContactoComponent },
    { path: 'somos', component: SomosComponent },
    { path: 'home', component: HomeComponent },
    { path: '**', redirectTo: 'home', pathMatch: 'full' },
];

