import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { HistoriaClinica } from '../../interfaces/HistoriaClinica';
import { HistoriaClinicaService } from '../../services/historia-clinica.service';


@Component({
  selector: 'app-historial-med',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  templateUrl: './historiaClinica.component.html',
  styleUrl: './historiaClinica.component.css'
})
export class HistorialMedComponent {
  Historias: HistoriaClinica[] = [];
 
  constructor(private _historiaClinicaservice: HistoriaClinicaService) { }
  
  ngOnInit(): void {
      this.getHistorias;
  }

  getHistorias(): void {
    this._historiaClinicaservice.getHistorias().subscribe({
      next: data => {
        this.Historias = data;
      },
      error: error => {
        alert("Ocurrió un error al obtener las historias clinicas");
      },
      complete: () => {
        console.info('Obtención de historia clinica completa');
      }
    });
  }

  getHistoria(HistoriaClinicaId: number): void {
    this._historiaClinicaservice.getHistoria(HistoriaClinicaId).subscribe({
      next: data => {
        console.log(data);
        this._historiaClinicaservice;
      },
      error: error => {
        alert("Ocurrió un error al obtener la historia clinica");
      },
      complete: () => {
        console.info('Obtención de historia clinica completa');
      }
    });
  }

  agregarHistoria(historiaClinica: HistoriaClinica): void {
    this._historiaClinicaservice.addHistoria(historiaClinica).subscribe({
      next: data => {
        this.Historias.push(data);
      },
      error: error => {
        alert("Ocurrió un error al agregar la historia clinica");
      },
      complete: () => {
        console.info('Historia clinica agregada correctamente');
      }
    });
  }

  actualizarHistoria(HistoriaClinicaId: number, historiaClinica: HistoriaClinica): void {
    this._historiaClinicaservice.updateHistoria(HistoriaClinicaId, historiaClinica).subscribe({
      next: () => {
        const index = this.Historias.findIndex(h => h.HistoriaClinicaId === HistoriaClinicaId);
        if (index !== -1) {
          this.Historias[index] = historiaClinica;
        }
      },
      error: error => {
        alert("Ocurrió un error al actualizar la historia clinica");
      },
      complete: () => {
        console.info('Historia clinica actualizada correctamente');
      }
    });
  }

  eliminarHistoria(HistoriaClinicaId: number): void {
    this._historiaClinicaservice.deleteHistoria(HistoriaClinicaId).subscribe({
      next: () => {
        this.Historias = this.Historias.filter(h => h.HistoriaClinicaId !== HistoriaClinicaId);
      },
      error: error => {
        alert("Ocurrió un error al eliminar la historia clinica");
      },
      complete: () => {
        console.info('Historia clinica eliminada correctamente');
      }
    });
  }
}
