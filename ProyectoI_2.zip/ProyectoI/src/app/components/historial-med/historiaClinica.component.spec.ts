import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HistorialMedComponent } from './historiaClinica.component';

describe('HistorialMedComponent', () => {
  let component: HistorialMedComponent;
  let fixture: ComponentFixture<HistorialMedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HistorialMedComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HistorialMedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
