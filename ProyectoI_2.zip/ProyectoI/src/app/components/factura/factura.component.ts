import { Component } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { Factura } from '../../interfaces/Factura';
import { FacturaService } from '../../services/factura.service';

@Component({
  selector: 'app-factura',
  standalone: true,
  imports: [HttpClientModule, RouterModule],
  templateUrl: './factura.component.html',
  styleUrl: './factura.component.css'
})
export class FacturaComponent {
  Facturas: Factura[] = [];
  
  constructor(private _facturaservice: FacturaService) { }
  
  ngOnInit(): void {
      this.getFacturas;
      this.getFactura;
      this.agregarFactura;
      this.actualizarFactura;
      this.eliminarFactura;
  }

  getFacturas(): void {
    this._facturaservice.getFacturas().subscribe({
      next: data => {
        this.Facturas = data;
      },
      error: error => {
        alert("Ocurrió un error al obtener las facturas");
      },
      complete: () => {
        console.info('Obtención de facturas completa');
      }
    });
  }

  getFactura(FacturaId: number): void {
    this._facturaservice.getFactura(FacturaId).subscribe({
      next: data => {
        console.log(data);
        this._facturaservice;
      },
      error: error => {
        alert("Ocurrió un error al obtener la factura");
      },
      complete: () => {
        console.info('Obtención de factura completa');
      }
    });
  }

  agregarFactura(factura: Factura): void {
    this._facturaservice.addFactura(factura).subscribe({
      next: data => {
        this.Facturas.push(data);
      },
      error: error => {
        alert("Ocurrió un error al agregar la factura");
      },
      complete: () => {
        console.info('Factura agregada correctamente');
      }
    });
  }

  actualizarFactura(FacturaId: number, factura: Factura): void {
    this._facturaservice.updateFactura(FacturaId, factura).subscribe({
      next: () => {
        const index = this.Facturas.findIndex(f => f.FacturaId === FacturaId);
        if (index !== -1) {
          this.Facturas[index] = factura;
        }
      },
      error: error => {
        alert("Ocurrió un error al actualizar la factura");
      },
      complete: () => {
        console.info('Factura actualizada correctamente');
      }
    });
  }

  eliminarFactura(FacturaId: number): void {
    this._facturaservice.deleteFactura(FacturaId).subscribe({
      next: () => {
        this.Facturas = this.Facturas.filter(f => f.FacturaId !== FacturaId);
      },
      error: error => {
        alert("Ocurrió un error al eliminar la factura");
      },
      complete: () => {
        console.info('Factura eliminada correctamente');
      }
    });
  }
}
