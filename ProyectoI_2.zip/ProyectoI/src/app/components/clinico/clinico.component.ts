import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';


@Component({
  selector: 'app-clinico',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  templateUrl: './clinico.component.html',
  styleUrl: './clinico.component.css'
})
export class ClinicoComponent {
  
}
