import { Component } from '@angular/core';

@Component({
  selector: 'app-agendar-cita',
  standalone: true,
  imports: [],
  templateUrl: './agendar-cita.component.html',
  styleUrl: './agendar-cita.component.css'
})
export class AgendarCitaComponent {

}
