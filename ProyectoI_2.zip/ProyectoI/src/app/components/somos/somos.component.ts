import { Component } from '@angular/core';

@Component({
  selector: 'app-somos',
  standalone: true,
  imports: [],
  templateUrl: './somos.component.html',
  styleUrl: './somos.component.css'
})
export class SomosComponent {

}
