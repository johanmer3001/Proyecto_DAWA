import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { CommonModule, } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-doctores',
  standalone: true,
  imports: [RouterLink, RouterOutlet, CommonModule, FormsModule],
  templateUrl: './doctores.component.html',
  styleUrl: './doctores.component.css'
})
export class DoctoresComponent {
  doctores = [
    {
      nombre: 'Juan Pérez',
      cedula: '1234567890',
      especialidad: 'Cardiología',
      numeroCelular: '0987654321',
      edad: 40,
      registro: '0956198097',
      cod: 50,
      horarios: ['8:00 - 14:00', '8:00 - 14:00', '8:00 - 14:00', '8:00 - 14:00', '8:00 - 14:00', '', '']
    },
    {
      nombre: 'María González',
      cedula: '0987654321',
      especialidad: 'Pediatría',
      numeroCelular: '0123456789',
      edad: 35,
      registro: '0954648741',
      cod: 52,
      horarios: ['10:00 - 18:00', '10:00 - 18:00', '10:00 - 18:00', '10:00 - 18:00', '', '', '']
    },
    {
      nombre: 'Carlos Martínez',
      cedula: '5432167890',
      especialidad: 'Neurología',
      numeroCelular: '9876543210',
      edad: 45,
      registro: '0956319806',
      cod: 60,
      horarios: ['9:00 - 17:00', '9:00 - 17:00', '', '9:00 - 17:00', '9:00 - 17:00', '', '']
    }

  ];
  diasSemana = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

}
