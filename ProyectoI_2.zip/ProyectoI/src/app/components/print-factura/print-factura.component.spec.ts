import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintFacturaComponent } from './print-factura.component';

describe('PrintFacturaComponent', () => {
  let component: PrintFacturaComponent;
  let fixture: ComponentFixture<PrintFacturaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrintFacturaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PrintFacturaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
