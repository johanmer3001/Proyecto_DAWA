import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-print-factura',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  templateUrl: './print-factura.component.html',
  styleUrl: './print-factura.component.css'
})
export class PrintFacturaComponent {




}
