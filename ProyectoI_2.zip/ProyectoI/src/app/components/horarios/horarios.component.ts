import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-horarios',
  standalone: true,
  imports: [RouterLink, RouterOutlet, CommonModule, FormsModule],
  templateUrl: './horarios.component.html',
  styleUrl: './horarios.component.css'
})
export class HorariosComponent {
  medicos = [
    {
      nombre: 'Dr. Pérez',
      especialidad: 'Traumatologia',
      cupos: '10',
      horario: ['8:00 - 12:00', '13:00 - 17:00', '8:00 - 12:00', '13:00 - 17:00', '8:00 - 12:00', 'No atiende', 'No atiende']
    },
    {
      nombre: 'Dra. García',
      especialidad: 'Medicina General',
      cupos: '15',
      horario: ['9:00 - 13:00', 'No atiende', '9:00 - 13:00', '13:00 - 17:00', '9:00 - 13:00', 'No atiende', 'No atiende']
    },
    {
      nombre: 'Dra. Gonzalez',
      especialidad: 'Medicina General',
      cupos: '5',
      horario: ['14:00 - 16:00', 'No atiende', '14:00 - 16:00', 'No atiende', '14:00 - 16:00', 'No atiende', 'No atiende']
    },
    {
      nombre: 'Dr. Solorzano',
      especialidad: 'Otorrinolaringologia',
      cupos: '30',
      horario: ['10:00 - 13:00', '10:00 - 13:00', 'No atiende', 'No atiende', 'No atiende', 'No atiende', 'No atiende']
    },
    {
      nombre: 'Dr. Coronado',
      especialidad: 'Cardiologia',
      cupos: '15',
      horario: ['14:00 - 18:00', '9:00 - 13:00', '14:00 - 18:00', '9:00 - 13:00', '14:00 - 18:00', 'No atiende', 'No atiende']
    },
    {
      nombre: 'Dra. Arevalo',
      especialidad: 'Pediatria',
      cupos: '5',
      horario: ['No atiende', 'No atiende', '10:00 - 13:00', '9:00 - 13:00', '10:00 - 13:00', '8:00 - 11:00', 'No atiende']
    },
  ];

  filtroNombre: string = '';

  filtrarMedicos() {
    return this.medicos.filter(medico =>
      medico.nombre.toLowerCase().includes(this.filtroNombre.toLowerCase())
    );
  }

  getColor(horario: string): any {

    return { color: horario === 'No atiende' ? 'red' : 'green' };

  }


}
