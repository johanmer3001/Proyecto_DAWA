import { Component } from '@angular/core';

@Component({
  selector: 'app-diagnostico',
  standalone: true,
  imports: [],
  templateUrl: './diagnostico.component.html',
  styleUrl: './diagnostico.component.css'
})
export class DiagnosticoComponent {

}
