import { HistoriaClinica } from "./HistoriaClinica";

export interface Diagnostico {
    DiagnosticoId?: number,
    FechaHora: Date,
    Descripcion: string,
    Estado: string,
    HistoriaClinicaId: number,
    HistoriaClinica: HistoriaClinica
}