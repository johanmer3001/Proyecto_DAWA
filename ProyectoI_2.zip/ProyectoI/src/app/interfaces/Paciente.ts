
export interface Paciente {
    PacienteId?: number,
    Nombre: string,
    Contraseña: string,
    CorreoElectronico: string,
    FechaRegistro: Date
}