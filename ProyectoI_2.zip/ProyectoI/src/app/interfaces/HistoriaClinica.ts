import { Paciente } from "./Paciente";

export interface HistoriaClinica {
    HistoriaClinicaId?: number,
    FechaCreacion: Date,
    Alergia: string,
    MedicacionActual: string,
    AntecedenteMedico: string,
    PacienteId: number,
    Paciente: Paciente,
}