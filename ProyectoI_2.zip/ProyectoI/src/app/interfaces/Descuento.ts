
export interface Descuento {
    DescuentoId?: number,
    Descripcion: string,
    Porcentaje: number
}