import { Descuento } from "./Descuento";
import { Paciente } from "./Paciente";

export interface Factura {
    FacturaId?: number,
    FechaEmision: Date,
    Total: number,
    MetodoPago: string,
    Estado: string,
    PacienteId: number,
    DescuentoId: number,
    Paciente: Paciente,
    Descuento: Descuento
}