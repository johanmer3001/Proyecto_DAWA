import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HistoriaClinica } from '../interfaces/HistoriaClinica';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HistoriaClinicaService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = '/api/HistoriaClinica';

  constructor(private http: HttpClient) { }

  getHistorias(): Observable<HistoriaClinica[]> {
    return this.http.get<HistoriaClinica[]>(`${this.myAppUrl}${this.myApiUrl}`);
  }

  getHistoria(FacturaId: number): Observable<HistoriaClinica> {
    return this.http.get<HistoriaClinica>(`${this.myAppUrl}${this.myApiUrl}/${FacturaId}`);
  }
  addHistoria(historiaClinica: HistoriaClinica): Observable<HistoriaClinica> {
    return this.http.post<HistoriaClinica>(`${this.myAppUrl}${this.myApiUrl}`, historiaClinica);
  }

  updateHistoria(HistoriaClinicaId: number, historiaClinica: HistoriaClinica): Observable<void> {
    return this.http.put<void>(`${this.myAppUrl}${this.myApiUrl}/${HistoriaClinicaId}`, historiaClinica);
  }

  deleteHistoria(HistoriaClinicaId: number): Observable<void> {
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}/${HistoriaClinicaId}`); 
  }
}


