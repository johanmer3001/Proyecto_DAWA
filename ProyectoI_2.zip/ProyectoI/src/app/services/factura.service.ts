import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Factura } from '../interfaces/Factura';

@Injectable({
  providedIn: 'root'
})
export class FacturaService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = '/api/Factura';

  constructor(private http: HttpClient) { }

  getFacturas(): Observable<Factura[]> {
    return this.http.get<Factura[]>(`${this.myAppUrl}${this.myApiUrl}`);
  }

  getFactura(FacturaId: number): Observable<Factura> {
    return this.http.get<Factura>(`${this.myAppUrl}${this.myApiUrl}/${FacturaId}`);
  }
  addFactura(factura: Factura): Observable<Factura> {
    return this.http.post<Factura>(`${this.myAppUrl}${this.myApiUrl}`, factura);
  }

  updateFactura(FacturaId: number, factura: Factura): Observable<void> {
    return this.http.put<void>(`${this.myAppUrl}${this.myApiUrl}/${FacturaId}`, factura);
  }

  deleteFactura(FacturaId: number): Observable<void> {
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}/${FacturaId}`); 
  }
}
