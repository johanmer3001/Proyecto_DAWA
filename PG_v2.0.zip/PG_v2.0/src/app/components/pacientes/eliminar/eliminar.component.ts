import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PacientesService } from '../../../services/pacientes.service';
import { Pacientes } from '../../../interface/Pacientes';

@Component({
  selector: 'app-pacientes-eliminar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './eliminar.component.html',
  styleUrls: ['./eliminar.component.css']
})
export class PacientesEliminarComponent implements OnInit {
  paciente: Pacientes | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private pacientesService: PacientesService
  ) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.pacientesService.getPacientePorId(id).subscribe(
      (data: Pacientes) => {
        this.paciente = data;
      },
      (error) => console.error('Error al obtener paciente', error)
    );
  }

  onDelete(): void {
    if (this.paciente) {
      this.pacientesService.deletePaciente(this.paciente.id).subscribe(
        () => {
          console.log('Paciente eliminado');
          this.router.navigate(['/pacientes/listar']);
        },
        (error) => console.error('Error al eliminar paciente', error)
      );
    }
  }

  onCancel(): void {
    this.router.navigate(['/pacientes/listar']);
  }
}
