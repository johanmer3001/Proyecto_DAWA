/*
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { PacientesService } from '../../../services/pacientes.service';
import { Pacientes } from '../../../interface/Pacientes';

@Component({
  selector: 'app-pacientes-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule]
})
export class PacientesListarComponent implements OnInit {
  id!: number;
  listadoPacientes: Pacientes[] = [];

  constructor(private _pacientesService: PacientesService) { }

  ngOnInit(): void {
    this.getPacientes();
  }

  getPacientes(): void {
    this._pacientesService.getPacientes().subscribe({
      next: data => {
        console.log(data);
        this.listadoPacientes = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de Pacientes completa');
      }
    });
  }

  deletePaciente(id?: number): void {
    if (id === undefined) {
      alert('El ID del paciente es indefinido');
      return;
    }

    this._pacientesService.deletePaciente(id).subscribe({
      next: data => {
        console.log('Paciente eliminado:', data);
        this.getPacientes();
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Eliminación de paciente completa');        
      }
    });
  }
}
*/
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { PacientesService } from '../../../services/pacientes.service';
import { Pacientes } from '../../../interface/Pacientes';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-pacientes-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, ReactiveFormsModule]
})
export class PacientesListarComponent implements OnInit {
  id!: number;
  listadoPacientes: Pacientes[] = [];
  filtroFechaForm: FormGroup;
  filtroNombreForm: FormGroup;
  filtroIdForm: FormGroup;

  constructor(
    private _pacientesService: PacientesService,
    private fb: FormBuilder
  ) {
    this.filtroFechaForm = this.fb.group({
      fechaInicio: ['', Validators.required],
      fechaFin: ['', Validators.required]
    });

    this.filtroNombreForm = this.fb.group({
      nombrePaciente: ['', Validators.required]
    });

    this.filtroIdForm = this.fb.group({
      id: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.getPacientes();
  }

  getPacientes(): void {
    this._pacientesService.getPacientes().subscribe({
      next: data => {
        console.log(data);
        this.listadoPacientes = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de Pacientes completa');
      }
    });
  }

  deletePaciente(id?: number): void {
    if (id === undefined) {
      alert('El ID del paciente es indefinido');
      return;
    }

    this._pacientesService.deletePaciente(id).subscribe({
      next: data => {
        console.log('Paciente eliminado:', data);
        this.getPacientes();
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Eliminación de paciente completa');        
      }
    });
  }

  getPacientesPorFecha(): void {
    const { fechaInicio, fechaFin } = this.filtroFechaForm.value;
    this._pacientesService.getPacientesPorFechaRegistro(new Date(fechaInicio), new Date(fechaFin)).subscribe({
      next: data => {
        console.log('Pacientes obtenidos por fecha:', data);
        this.listadoPacientes = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de pacientes por fecha completa');
      }
    });
  }

  getPacientesPorNombre(): void {
    const { nombrePaciente } = this.filtroNombreForm.value;
    this._pacientesService.getPacientesPorNombre(nombrePaciente).subscribe({
      next: data => {
        console.log('Pacientes obtenidos por nombre:', data);
        this.listadoPacientes = data; // Lista de pacientes
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de pacientes por nombre completa');
      }
    });
  }

  getPacientePorId(): void {
    const { id } = this.filtroIdForm.value;
    this._pacientesService.getPacientePorId(id).subscribe({
      next: data => {
        console.log('Paciente obtenido por ID:', data);
        this.listadoPacientes = [data]; // Asumiendo que solo se obtiene un paciente
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de paciente por ID completa');
      }
    });
  }
}
