import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PacientesListarComponent } from './listar.component';

describe('PacientesListarComponent', () => { // Asegúrate de que el nombre del componente sea consistente
  let component: PacientesListarComponent;
  let fixture: ComponentFixture<PacientesListarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PacientesListarComponent] // Asegúrate de que PacientesListarComponent esté en los imports
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PacientesListarComponent); // Asegúrate de que el nombre del componente sea consistente
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
