import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PacientesService } from '../../../services/pacientes.service';
import { Pacientes } from '../../../interface/Pacientes';

@Component({
  selector: 'app-pacientes-editar',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './editar.component.html',
  styleUrls: ['./editar.component.css']
})
export class PacientesEditarComponent implements OnInit {
  pacienteForm: FormGroup;
  paciente: Pacientes | null = null;
  fotoBase64: string | ArrayBuffer | null = null;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private pacientesService: PacientesService
  ) {
    this.pacienteForm = this.fb.group({
      nombre: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
      contraseña: ['', Validators.required],
      fechaRegistro: ['', Validators.required],
      foto: [''],
      biografia: [''],
      estado: [{ value: true, disabled: true }, Validators.required]
    });
  }

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.pacientesService.getPacientePorId(id).subscribe(
      (data: Pacientes) => {
        this.paciente = data;
        // Formatear fecha a "yyyy-MM-dd"
        const fechaRegistroFormateada = this.formatDate(data.fechaRegistro);
        this.pacienteForm.patchValue({ ...data, fechaRegistro: fechaRegistroFormateada, estado: true });
      },
      (error) => console.error('Error al obtener paciente', error)
    );
  }
  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.fotoBase64 = reader.result;
        this.pacienteForm.patchValue({ foto: this.fotoBase64 });
      };
      reader.readAsDataURL(file);
    }
  }
  formatDate(fecha: string): string {
    const date = new Date(fecha);
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return `${year}-${month}-${day}`;
  }

  onSubmit(): void {
    if (this.pacienteForm.valid && this.paciente) {
      const updatedPaciente: Pacientes = {
        ...this.paciente,
        ...this.pacienteForm.value,
        estado: true // Asegurarse de que el estado sea true al actualizar
      };
      const id = this.paciente.id; // Asegúrate de obtener el id del paciente
      this.pacientesService.updatePaciente(id, updatedPaciente).subscribe(
        () => {
          console.log('Paciente actualizado');
          this.router.navigate(['/pacientes/listar']);
        },
        (error) => console.error('Error al actualizar paciente', error)
      );
    }
  }

  onCancel(): void {
    this.router.navigate(['/pacientes/listar']);
  }
}
