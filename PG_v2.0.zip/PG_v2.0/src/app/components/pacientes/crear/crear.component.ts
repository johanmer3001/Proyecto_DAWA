import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PacientesService } from '../../../services/pacientes.service';
import { Pacientes } from '../../../interface/Pacientes';

@Component({
  selector: 'app-pacientes-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class PacientesCrearComponent implements OnInit {
  pacienteForm!: FormGroup;
  fotoBase64: string | ArrayBuffer | null = null;

  constructor(
    private formBuilder: FormBuilder,
    private pacientesService: PacientesService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.pacienteForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
      contraseña: ['', Validators.required],
      fechaRegistro: [new Date().toISOString().split('T')[0], Validators.required],
      foto: [''],
      biografia: [''],
      estado: [true]
    });
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.fotoBase64 = reader.result;
        this.pacienteForm.patchValue({ foto: this.fotoBase64 });
      };
      reader.readAsDataURL(file);
    }
  }

  createPaciente(): void {
    if (this.pacienteForm.valid) {
      const paciente: Pacientes = {
        id: 0,
        nombre: this.pacienteForm.value.nombre,
        correo: this.pacienteForm.value.correo,
        contraseña: this.pacienteForm.value.contraseña,
        fechaRegistro: new Date(this.pacienteForm.value.fechaRegistro).toISOString(),
        foto: this.pacienteForm.value.foto, // Enviar el archivo en formato base64
        biografia: this.pacienteForm.value.biografia,
        estado: this.pacienteForm.value.estado
      };

      this.pacientesService.createPaciente(paciente).subscribe({
        next: (data) => {
          console.log('Paciente creado:', data);
          this.router.navigate(['/pacientes/listar']);
        },
        error: (error) => {
          console.error('Error al crear paciente:', error);
          alert('Ocurrió un error al crear el paciente.');
        }
      });
    } else {
      console.error('Formulario inválido');
    }
  }
}
