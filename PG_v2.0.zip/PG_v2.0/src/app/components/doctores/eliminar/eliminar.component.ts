import { Component } from '@angular/core';

@Component({
  selector: 'app-doctores-eliminar',
  standalone: true,
  imports: [],
  templateUrl: './eliminar.component.html',
  styleUrl: './eliminar.component.css'
})
export class DoctorEliminarComponent {

}
