import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DoctoresListarComponent } from './listar.component';

describe('DoctoresListarComponent', () => {
  let component: DoctoresListarComponent;
  let fixture: ComponentFixture<DoctoresListarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DoctoresListarComponent] // Asegúrate de que DoctoresListarComponent esté en los imports
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DoctoresListarComponent); // Asegúrate de que el nombre del componente sea consistente
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Agrega pruebas específicas para el nuevo método y formulario si es necesario
});
