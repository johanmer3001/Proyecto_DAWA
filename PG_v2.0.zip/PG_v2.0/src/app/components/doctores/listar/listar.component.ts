import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { DoctoresService } from '../../../services/doctores.service';
import { Doctores } from '../../../interface/Doctores';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-doctores-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, ReactiveFormsModule]
})
export class DoctoresListarComponent implements OnInit {
  listadoDoctores: Doctores[] = [];
  filtroEspecialidadForm: FormGroup;
  filtroDisponibilidadForm: FormGroup;
  filtroIdForm: FormGroup;

  constructor(
    private _doctoresService: DoctoresService,
    private fb: FormBuilder
  ) {
    this.filtroEspecialidadForm = this.fb.group({
      especialidad: ['', Validators.required]
    });

    this.filtroDisponibilidadForm = this.fb.group({
      disponibilidad: ['', Validators.required]
    });

    this.filtroIdForm = this.fb.group({
      id: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.getDoctores();
  }

  getDoctores(): void {
    this._doctoresService.getDoctores().subscribe({
      next: data => {
        console.log(data);
        this.listadoDoctores = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de Doctores completa');
      }
    });
  }

  deleteDoctor(id?: number): void {
    if (id === undefined) {
      alert('El ID del doctor es indefinido');
      return;
    }

    this._doctoresService.deleteDoctor(id).subscribe({
      next: data => {
        console.log('Doctor eliminado:', data);
        this.getDoctores();
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Eliminación de doctor completa');        
      }
    });
  }

  getDoctoresPorEspecialidad(): void {
    const { especialidad } = this.filtroEspecialidadForm.value;
    if (especialidad && especialidad.trim() !== '') {
      this._doctoresService.getDoctoresPorEspecialidad(especialidad).subscribe({
        next: data => {
          console.log('Doctores obtenidos por especialidad:', data);
          this.listadoDoctores = data;
        },
        error: error => {
          console.error('Error al obtener doctores por especialidad:', error);
          alert("Ocurrió un error al obtener doctores por especialidad.");
        },
        complete: () => {
          console.info('Obtención de doctores por especialidad completa');
        }
      });
    } else {
      alert('Por favor ingrese una especialidad válida.');
    }
  }
  
  

  getDoctoresPorDisponibilidad(): void {
    const { disponibilidad } = this.filtroDisponibilidadForm.value;
    this._doctoresService.getDoctoresPorDisponibilidad(disponibilidad).subscribe({
      next: data => {
        console.log('Doctores obtenidos por disponibilidad:', data);
        this.listadoDoctores = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de doctores por disponibilidad completa');
      }
    });
  }

  getDoctorPorId(): void {
    const { id } = this.filtroIdForm.value;
    this._doctoresService.getDoctorPorId(id).subscribe({
      next: data => {
        console.log('Doctor obtenido por ID:', data);
        this.listadoDoctores = [data]; // Asumiendo que solo se obtiene un doctor
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de doctor por ID completa');
      }
    });
  }
}
