import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DoctoresService } from '../../../services/doctores.service';
import { Doctores } from '../../../interface/Doctores';

@Component({
  selector: 'app-doctores-editar',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './editar.component.html',
  styleUrls: ['./editar.component.css']
})
export class DoctoresEditarComponent implements OnInit {
  doctorForm: FormGroup;
  doctor: Doctores | null = null;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private doctoresService: DoctoresService
  ) {
    this.doctorForm = this.fb.group({
      nombre: ['', Validators.required],
      especialidad: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
      telefono: [''],
      ubicacion: ['', Validators.required],
      disponibilidad: [true],
      diasLaborales: this.fb.array([]),
      jornada: ['matutina', Validators.required],
      horario: this.fb.array([]),
      estado: [{ value: true, disabled: true }, Validators.required]
    });
  }

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.doctoresService.getDoctorPorId(id).subscribe(
      (data: Doctores) => {
        this.doctor = data;
        // Cargar los datos en el formulario
        this.doctorForm.patchValue({
          nombre: data.nombre,
          especialidad: data.especialidad,
          correo: data.correo,
          telefono: data.telefono,
          ubicacion: data.ubicacion,
          disponibilidad: data.disponibilidad,
          jornada: data.jornada,
          estado: data.estado
        });
        this.setDiasLaborales(data.diasLaborales);
        this.setHorario(data.horario);
      },
      (error) => console.error('Error al obtener doctor', error)
    );
  }

  get diasLaborales(): FormArray {
    return this.doctorForm.get('diasLaborales') as FormArray;
  }

  get horario(): FormArray {
    return this.doctorForm.get('horario') as FormArray;
  }

  setDiasLaborales(dias: string[]): void {
    const control = this.doctorForm.get('diasLaborales') as FormArray;
    dias.forEach(dia => {
      control.push(this.fb.control(dia));
    });
  }

  setHorario(horario: string[]): void {
    const control = this.doctorForm.get('horario') as FormArray;
    horario.forEach(hora => {
      control.push(this.fb.control(hora));
    });
  }

  addDiaLaboral(): void {
    this.diasLaborales.push(this.fb.control(''));
  }

  addHorario(): void {
    this.horario.push(this.fb.control(''));
  }

  onSubmit(): void {
    if (this.doctorForm.valid && this.doctor) {
      const updatedDoctor: Doctores = {
        ...this.doctor,
        ...this.doctorForm.value,
        estado: true // Asegurarse de que el estado sea true al actualizar
      };
      const id = this.doctor.id; // Asegúrate de obtener el id del doctor
      this.doctoresService.updateDoctor(id, updatedDoctor).subscribe(
        () => {
          console.log('Doctor actualizado');
          this.router.navigate(['/doctores/listar']);
        },
        (error) => console.error('Error al actualizar doctor', error)
      );
    }
  }

  onCancel(): void {
    this.router.navigate(['/doctores/listar']);
  }
}
