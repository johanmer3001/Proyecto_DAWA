import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { DoctoresService } from '../../../services/doctores.service';
import { Doctores } from '../../../interface/Doctores';

@Component({
  selector: 'app-doctores-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class DoctoresCrearComponent implements OnInit {
  doctorForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private doctoresService: DoctoresService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.doctorForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      especialidad: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
      telefono: [''],
      ubicacion: ['', Validators.required],
      disponibilidad: [true],
      diasLaborales: this.formBuilder.array([]),
      jornada: ['matutina', Validators.required], // Valor por defecto "matutina"
      horario: this.formBuilder.array([]),
      estado: [true]
    });
  }

  get diasLaborales(): FormArray {
    return this.doctorForm.get('diasLaborales') as FormArray;
  }

  get horario(): FormArray {
    return this.doctorForm.get('horario') as FormArray;
  }

  addDiaLaboral(): void {
    this.diasLaborales.push(this.formBuilder.control(''));
  }

  addHorario(): void {
    this.horario.push(this.formBuilder.control(''));
  }

  createDoctor(): void {
    if (this.doctorForm.valid) {
      const doctor: Doctores = {
        id: 0,
        nombre: this.doctorForm.value.nombre,
        especialidad: this.doctorForm.value.especialidad,
        correo: this.doctorForm.value.correo,
        telefono: this.doctorForm.value.telefono,
        ubicacion: this.doctorForm.value.ubicacion,
        disponibilidad: this.doctorForm.value.disponibilidad,
        diasLaborales: this.doctorForm.value.diasLaborales,
        jornada: this.doctorForm.value.jornada, // Valor seleccionado del select
        horario: this.doctorForm.value.horario,
        estado: this.doctorForm.value.estado
      };

      this.doctoresService.createDoctor(doctor).subscribe({
        next: (data) => {
          console.log('Doctor creado:', data);
          this.router.navigate(['/doctores/listar']);
        },
        error: (error) => {
          console.error('Error al crear doctor:', error);
          alert('Ocurrió un error al crear el doctor.');
        }
      });
    } else {
      console.error('Formulario inválido');
    }
  }
}
