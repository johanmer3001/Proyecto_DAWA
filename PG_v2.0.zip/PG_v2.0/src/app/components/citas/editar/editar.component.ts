import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CitasService } from '../../../services/citas.service';
import { PacientesService } from '../../../services/pacientes.service';
import { DoctoresService } from '../../../services/doctores.service';
import { Pacientes } from '../../../interface/Pacientes';
import { Doctores } from '../../../interface/Doctores';
import { Citas } from '../../../interface/Citas';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-citas-editar',
  templateUrl: './editar.component.html',
  styleUrls: ['./editar.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class CitasEditarComponent implements OnInit {
  citaForm!: FormGroup;
  cita: Citas | null = null;
  pacientes: Pacientes[] = [];
  doctores: Doctores[] = [];

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private citasService: CitasService,
    private pacientesService: PacientesService,
    private doctoresService: DoctoresService
  ) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.citasService.getCitaById(id).subscribe(
      (data: Citas) => {
        this.cita = data;
        this.initForm(data);
      },
      (error) => console.error('Error al obtener cita', error)
    );

    this.loadPacientes();
    this.loadDoctores();
  }

  initForm(cita: Citas): void {
    this.citaForm = this.fb.group({
      idPacientes: [cita.idPacientes, Validators.required],
      idDoctores: [cita.idDoctores, Validators.required],
      fechaCita: [this.formatDate(cita.fechaCita), Validators.required],
      horaSeleccionada: [cita.horaSeleccionada],
      estado: [cita.estado],
      registrada: [true, Validators.required]
    });
  }

  formatDate(fecha: Date): string {
    const date = new Date(fecha);
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return `${year}-${month}-${day}`;
  }

  loadPacientes(): void {
    this.pacientesService.getPacientes().subscribe(pacientes => this.pacientes = pacientes);
  }

  loadDoctores(): void {
    this.doctoresService.getDoctores().subscribe(doctores => this.doctores = doctores);
  }

  onSubmit(): void {
    if (this.citaForm.valid && this.cita) {
      const updatedCita: Citas = {
        ...this.cita,
        ...this.citaForm.value,
        registrada: true
      };
      const id = this.cita.id;
      this.citasService.updateCita(updatedCita).subscribe(
        () => {
          console.log('Cita actualizada');
          this.router.navigate(['/citas/listar']);
        },
        (error) => console.error('Error al actualizar cita', error)
      );
    }
  }

  onCancel(): void {
    this.router.navigate(['/citas/listar']);
  }
}
