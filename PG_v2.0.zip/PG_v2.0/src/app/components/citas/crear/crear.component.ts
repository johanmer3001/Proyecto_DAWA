import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CitasService } from '../../../services/citas.service';
import { Citas } from '../../../interface/Citas';
import { PacientesService } from '../../../services/pacientes.service';
import { DoctoresService } from '../../../services/doctores.service';
import { Pacientes } from '../../../interface/Pacientes';
import { Doctores } from '../../../interface/Doctores';

@Component({
  selector: 'app-citas-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class CitasCrearComponent implements OnInit {
  citaForm!: FormGroup;
  pacientes: Pacientes[] = [];
  doctores: Doctores[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private citasService: CitasService,
    private pacientesService: PacientesService,
    private doctoresService: DoctoresService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.citaForm = this.formBuilder.group({
      idPacientes: ['', Validators.required],
      idDoctores: ['', Validators.required],
      fechaCita: ['', Validators.required],
      horaSeleccionada: ['', Validators.required],
      estado: ['pendiente'], // Puedes ajustar el valor predeterminado aquí
      registrada: [true]
    });

    this.loadPacientes();
    this.loadDoctores();
  }

  loadPacientes(): void {
    this.pacientesService.getPacientes().subscribe(pacientes => this.pacientes = pacientes);
  }

  loadDoctores(): void {
    this.doctoresService.getDoctores().subscribe(doctores => this.doctores = doctores);
  }

  createCita(): void {
    if (this.citaForm.valid) {
      const cita: Citas = {
        id: 0,
        idPacientes: this.citaForm.value.idPacientes,
        idDoctores: this.citaForm.value.idDoctores,
        fechaCita: new Date(this.citaForm.value.fechaCita), // Convierte la cadena a Date aquí
        horaSeleccionada: this.citaForm.value.horaSeleccionada, // Mantiene como string
        estado: this.citaForm.value.estado,
        registrada: this.citaForm.value.registrada
      };

      this.citasService.createCita(cita).subscribe({
        next: (data) => {
          console.log('Cita creada:', data);
          this.router.navigate(['/citas/listar']);
        },
        error: (error) => {
          console.error('Error al crear cita:', error);
          alert('Ocurrió un error al crear la cita.');
        }
      });
    } else {
      console.error('Formulario inválido');
    }
  }
}
