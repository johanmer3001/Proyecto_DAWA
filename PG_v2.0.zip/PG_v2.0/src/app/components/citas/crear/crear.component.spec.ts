import { TestBed, ComponentFixture } from '@angular/core/testing';
import { CitasCrearComponent } from './crear.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { CitasService } from '../../../services/citas.service';
import { of, throwError } from 'rxjs';
import { Router } from '@angular/router';

describe('CitasCrearComponent', () => {
  let component: CitasCrearComponent;
  let fixture: ComponentFixture<CitasCrearComponent>;
  let citasService: jasmine.SpyObj<CitasService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    // Crear espías para CitasService y Router
    const citasServiceSpy = jasmine.createSpyObj('CitasService', ['createCita']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, ReactiveFormsModule],
      declarations: [CitasCrearComponent],
      providers: [
        { provide: CitasService, useValue: citasServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CitasCrearComponent);
    component = fixture.componentInstance;
    citasService = TestBed.inject(CitasService) as jasmine.SpyObj<CitasService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form with default values', () => {
    expect(component.citaForm).toBeDefined();
    expect(component.citaForm.controls['fechaCita'].value).toBeDefined();
  });

  it('should call createCita and navigate on success', () => {
    // Simular una respuesta exitosa del servicio
    citasService.createCita.and.returnValue(of(1)); // Suponiendo que 1 es el ID de la nueva cita

    component.citaForm.setValue({
      idPacientes: 1,
      idDoctores: 1,
      fechaCita: '2024-08-10',
      horaSeleccionada: '10:00',
      estado: 'pendiente',
      registrada: true
    });

    component.createCita();

    expect(citasService.createCita).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith(['/citas/listar']);
  });

  it('should show error alert on createCita failure', () => {
    // Simular una respuesta de error del servicio
    citasService.createCita.and.returnValue(throwError(() => new Error('Error al crear cita')));

    spyOn(window, 'alert'); // Espiar la función alert global

    component.citaForm.setValue({
      idPacientes: 1,
      idDoctores: 1,
      fechaCita: '2024-08-10',
      horaSeleccionada: '10:00',
      estado: 'pendiente',
      registrada: true
    });

    component.createCita();

    expect(citasService.createCita).toHaveBeenCalled();
    expect(window.alert).toHaveBeenCalledWith('Ocurrió un error al crear la cita.');
  });
});
