import { Component } from '@angular/core';

@Component({
  selector: 'app-citas-eliminar',
  standalone: true,
  imports: [],
  templateUrl: './eliminar.component.html',
  styleUrl: './eliminar.component.css'
})
export class CitasEliminarComponent {

}
