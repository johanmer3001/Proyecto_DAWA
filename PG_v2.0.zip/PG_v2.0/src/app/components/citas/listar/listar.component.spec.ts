import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CitasListarComponent } from './listar.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('CitasListarComponent', () => {
  let component: CitasListarComponent;
  let fixture: ComponentFixture<CitasListarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        CitasListarComponent,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule
      ]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CitasListarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
