import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CitasService } from '../../../services/citas.service';
import { Citas } from '../../../interface/Citas';
import { PacientesService } from '../../../services/pacientes.service';
import { DoctoresService } from '../../../services/doctores.service';
import { Pacientes } from '../../../interface/Pacientes';
import { Doctores } from '../../../interface/Doctores';

@Component({
  selector: 'app-citas-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, ReactiveFormsModule]
})
export class CitasListarComponent implements OnInit {
  listadoCitas: Citas[] = [];
  filtroFechaForm: FormGroup;
  filtroDoctorForm: FormGroup;
  filtroIdForm: FormGroup;
  pacientes: Pacientes[] = [];
  doctores: Doctores[] = [];

  constructor(
    private _citasService: CitasService,
    private _pacientesService: PacientesService,
    private _doctoresService: DoctoresService,
    private fb: FormBuilder
  ) {
    this.filtroFechaForm = this.fb.group({
      fechaInicio: ['', Validators.required],
      fechaFin: ['', Validators.required]
    });

    this.filtroDoctorForm = this.fb.group({
      nombreDoctor: ['', Validators.required]
    });

    this.filtroIdForm = this.fb.group({
      id: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.getCitas();
    this.getPacientes();
    this.getDoctores();
  }

  getCitas(): void {
    this._citasService.getCitas().subscribe({
      next: data => {
        console.log(data);
        this.listadoCitas = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de Citas completa');
      }
    });
  }

  getPacientes(): void {
    this._pacientesService.getPacientes().subscribe({
      next: data => {
        this.pacientes = data;
      },
      error: error => {
        alert("Ocurrió un error al obtener pacientes");
      },
      complete: () => {
        console.info('Obtención de Pacientes completa');
      }
    });
  }

  getDoctores(): void {
    this._doctoresService.getDoctores().subscribe({
      next: data => {
        this.doctores = data;
      },
      error: error => {
        alert("Ocurrió un error al obtener doctores");
      },
      complete: () => {
        console.info('Obtención de Doctores completa');
      }
    });
  }

  deleteCita(id?: number): void {
    if (id === undefined) {
      alert('El ID de la cita es indefinido');
      return;
    }

    this._citasService.deleteCita(id).subscribe({
      next: () => {
        console.log('Cita eliminada');
        this.getCitas();
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Eliminación de cita completa');
      }
    });
  }

  getCitasPorFecha(): void {
    const { fechaInicio, fechaFin } = this.filtroFechaForm.value;
    this._citasService.getCitasPorRangoFecha(new Date(fechaInicio), new Date(fechaFin)).subscribe({
      next: data => {
        console.log('Citas obtenidas por fecha:', data);
        this.listadoCitas = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de citas por fecha completa');
      }
    });
  }

  getCitasPorNombreDoctor(): void {
    const { nombreDoctor } = this.filtroDoctorForm.value;
    this._citasService.getCitaPorNombreDoctor(nombreDoctor).subscribe({
      next: data => {
        console.log('Citas obtenidas por nombre del doctor:', data);
        this.listadoCitas = data;
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de citas por nombre del doctor completa');
      }
    });
  }

  getCitaPorId(): void {
    const { id } = this.filtroIdForm.value;
    this._citasService.getCitaById(id).subscribe({
      next: data => {
        console.log('Cita obtenida por ID:', data);
        this.listadoCitas = [data]; // Asumiendo que solo se obtiene una cita
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de cita por ID completa');
      }
    });
  }

  getPacienteNombre(id: number): string {
    const paciente = this.pacientes.find(p => p.id === id);
    return paciente ? paciente.nombre : 'Desconocido';
  }

  getDoctorNombre(id: number): string {
    const doctor = this.doctores.find(d => d.id === id);
    return doctor ? doctor.nombre : 'Desconocido';
  }
}
