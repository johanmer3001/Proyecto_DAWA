export interface Doctores {
    id: number;
    nombre: string;
    especialidad: string;
    correo: string;
    telefono?: string;
    ubicacion: string;
    disponibilidad: boolean;
    diasLaborales: string[];
    jornada: string;
    horario: string[];
    estado: boolean;
  }
  