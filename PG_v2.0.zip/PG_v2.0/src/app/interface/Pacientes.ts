export interface Pacientes {
  id: number;
  nombre: string;
  correo?: string;
  contraseña: string;
  fechaRegistro: string; // Usa string para manejar fechas en formato ISO
  foto?: string;
  biografia?: string;
  estado: boolean;
}
