import { Doctores } from "./Doctores";
import { Pacientes } from "./Pacientes";

export interface Citas {
  id: number;
  idPacientes: number;
  pacientes?: Pacientes;
  idDoctores: number;
  doctores?: Doctores;
  fechaCita: Date;
  horaSeleccionada?: string;
  estado?: string;
  registrada: boolean;
}
