import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pacientes } from '../interface/Pacientes';

@Injectable({
  providedIn: 'root'
})
export class PacientesService {
  private apiUrl = 'https://localhost:7101/api/Pacientes';

  constructor(private http: HttpClient) {}

  // Método para obtener todos los pacientes
  getPacientes(): Observable<Pacientes[]> {
    return this.http.get<Pacientes[]>(this.apiUrl);
  }

  // Método para obtener un paciente por ID
  getPacientePorId(id: number): Observable<Pacientes> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.get<Pacientes>(url);
  }

  // Obtener pacientes por rango de fecha
  getPacientesPorFechaRegistro(fechaInicio: Date, fechaFin: Date): Observable<Pacientes[]> {
    const params = new HttpParams()
      .set('fechaInicio', fechaInicio.toISOString())
      .set('fechaFin', fechaFin.toISOString());

    return this.http.get<Pacientes[]>(`${this.apiUrl}/por-rango-fecha`, { params });
  }

  // Obtener pacientes por nombre
  getPacientesPorNombre(nombrePaciente: string): Observable<Pacientes[]> {
    const params = new HttpParams().set('nombrePaciente', nombrePaciente);
    return this.http.get<Pacientes[]>(`${this.apiUrl}/por-nombre-paciente`, { params });
  }

  // Método para crear un nuevo paciente
  createPaciente(paciente: Pacientes): Observable<Pacientes> {
    const headers = new HttpHeaders({'Content-Type': 'application/json'});
    return this.http.post<Pacientes>(this.apiUrl, paciente, { headers });
  }

  // Método para actualizar un paciente existente
  updatePaciente(id: number, paciente: Pacientes): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    const headers = new HttpHeaders({'Content-Type': 'application/json'});
    return this.http.put<void>(url, paciente, { headers });
  }

  // Método para eliminar un paciente
  deletePaciente(id: number): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.delete<void>(url);
  }
}
