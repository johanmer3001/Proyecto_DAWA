import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { Citas } from '../interface/Citas';

@Injectable({
  providedIn: 'root'
})
export class CitasService {
  private ApiUrl: string = 'https://localhost:7101/api/Citas';

  constructor(private http: HttpClient) {}

  // Obtener todas las citas
  getCitas(): Observable<Citas[]> {
    return this.http.get<Citas[]>(`${this.ApiUrl}`);
  }

  // Obtener una cita por ID
  getCitaById(id: number): Observable<Citas> {
    return this.http.get<Citas>(`${this.ApiUrl}/${id}`);
  }

  // Obtener citas por rango de fecha
  getCitasPorRangoFecha(fechaInicio: Date, fechaFin: Date): Observable<Citas[]> {
    const params = new HttpParams()
      .set('fechaInicio', fechaInicio.toISOString())
      .set('fechaFin', fechaFin.toISOString());

    return this.http.get<Citas[]>(`${this.ApiUrl}/por-rango-fecha`, { params });
  }

  // Obtener cita por nombre de doctor
  getCitaPorNombreDoctor(nombreDoctor: string): Observable<Citas[]> { // Cambié a Observable<Citas[]> porque puede haber varias citas
    const params = new HttpParams().set('nombreDoctor', nombreDoctor);
    return this.http.get<Citas[]>(`${this.ApiUrl}/por-nombre-doctor`, { params });
  }

  // Crear una nueva cita
  createCita(cita: Citas): Observable<number> {
    return this.http.post<number>(`${this.ApiUrl}`, cita);
  }

  // Actualizar una cita existente
  updateCita(cita: Citas): Observable<number> {
    return this.http.put<number>(`${this.ApiUrl}/${cita.id}`, cita);
  }

  // Eliminar una cita
  deleteCita(id: number): Observable<void> {
    return this.http.delete<void>(`${this.ApiUrl}/${id}`);
  }
}
