import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { Doctores } from '../interface/Doctores';

@Injectable({
  providedIn: 'root'
})
export class DoctoresService {
  private ApiUrl: string = 'https://localhost:7101/api/Doctores';

  constructor(private http: HttpClient) {}

  // Obtener todos los doctores
  getDoctores(): Observable<Doctores[]> {
    return this.http.get<Doctores[]>(this.ApiUrl);
  }

  // Obtener un doctor por ID
  getDoctorPorId(id: number): Observable<Doctores> {
    return this.http.get<Doctores>(`${this.ApiUrl}/${id}`);
  }

  // Obtener doctores por especialidad
  getDoctoresPorEspecialidad(especialidad: string): Observable<Doctores[]> {
    const params = new HttpParams().set('especialidadDoctor', especialidad); // Asegúrate de usar el nombre correcto
    return this.http.get<Doctores[]>(`${this.ApiUrl}/por-especialidad`, { params });
  }
  

  // Obtener doctores por disponibilidad
  getDoctoresPorDisponibilidad(disponibilidad: boolean): Observable<Doctores[]> {
    const params = new HttpParams().set('disponibilidad', disponibilidad.toString());
    return this.http.get<Doctores[]>(`${this.ApiUrl}/por-disponibilidad`, { params });
  }

  // Crear un nuevo doctor
  createDoctor(doctor: Doctores): Observable<Doctores> {
    return this.http.post<Doctores>(this.ApiUrl, doctor);
  }

  // Actualizar un doctor existente
  updateDoctor(id: number, doctor: Doctores): Observable<void> {
    return this.http.put<void>(`${this.ApiUrl}/${id}`, doctor);
  }

  // Eliminar un doctor
  deleteDoctor(id: number): Observable<void> {
    return this.http.delete<void>(`${this.ApiUrl}/${id}`);
  }
}
