import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';

import { PacientesListarComponent } from './components/pacientes/listar/listar.component';
import { PacientesCrearComponent } from './components/pacientes/crear/crear.component';
import { PacientesEditarComponent } from './components/pacientes/editar/editar.component';
import { PacientesEliminarComponent } from './components/pacientes/eliminar/eliminar.component';

import { DoctoresListarComponent } from './components/doctores/listar/listar.component';
import { DoctoresCrearComponent } from './components/doctores/crear/crear.component';
import { DoctoresEditarComponent } from './components/doctores/editar/editar.component';
import { DoctorEliminarComponent } from './components/doctores/eliminar/eliminar.component';

import { CitasListarComponent } from './components/citas/listar/listar.component';
import { CitasCrearComponent } from './components/citas/crear/crear.component';
import { CitasEditarComponent } from './components/citas/editar/editar.component';
import { CitasEliminarComponent } from './components/citas/eliminar/eliminar.component';

export const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },

    // Rutas de Pacientes
    { path: 'pacientes', children: [
        { path: 'listar', component: PacientesListarComponent },
        { path: 'crear', component: PacientesCrearComponent },
        { path: 'editar/:id', component: PacientesEditarComponent },
        { path: 'eliminar/:id', component: PacientesEliminarComponent },
    ]},

    // Rutas de Doctores
    { path: 'doctores', children: [
        { path: 'listar', component: DoctoresListarComponent },
        { path: 'crear', component: DoctoresCrearComponent },
        { path: 'editar/:id', component: DoctoresEditarComponent },
        { path: 'eliminar/:id', component: DoctorEliminarComponent },
    ]},

    // Rutas de Citas
    { path: 'citas', children: [
        { path: 'listar', component: CitasListarComponent },
        { path: 'crear', component: CitasCrearComponent },
        { path: 'editar/:id', component: CitasEditarComponent },
        { path: 'eliminar/:id', component: CitasEliminarComponent },
    ]},

    { path: 'home', component: HomeComponent },
    { path: '**', redirectTo: 'home', pathMatch: 'full' },
];
