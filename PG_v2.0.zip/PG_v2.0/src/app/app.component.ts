
import { Component } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { CabeceraComponent } from './components/cabecera/cabecera.component';
import { HomeComponent } from './components/home/home.component';
import { PieComponent } from './components/pie/pie.component';
import { HttpClientModule } from '@angular/common/http'; // Asegúrate de importar esto
import { routes } from './app.routes';

@Component({
  selector: 'app-root',
  template: '<router-outlet></router-outlet>',
  standalone: true,
  imports: [
    RouterModule,
    RouterOutlet,
    CabeceraComponent,
    HomeComponent,
    PieComponent,
    HttpClientModule
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PG_v2.0';
}


/*
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CabeceraComponent } from './components/cabecera/cabecera.component';
@Component({
  selector: 'app-root',
  template: `
    <app-cabecera></app-cabecera>
    <router-outlet></router-outlet>
  `,
  standalone: true,
  imports: [RouterModule, CabeceraComponent]
})
export class AppComponent {}
*/